book = {"chap1":10 ,"chap2":20,"chap3":30}
print(book)
# add new key-value
book['chap4'] = 40
book['chap5'] = 50
print(book)
# display values
print(book['chap1'])
print(book['chap2'])
print(book['chap3'])
print(book.keys())  # display keys
print(book.values()) # display values
print(book.items())  # display key,value:list of tuples
print(book['chap20'])
# if key is not existing.. it retuns None
# if key is existing ... it returns the value
print(book.get('chap20'))

newbook = {"chap6":60 ,"chap7":70}
finalbook = {**book,**newbook}
print(finalbook)

#method2 - we are updating the book
book.update(newbook)
print(book)




