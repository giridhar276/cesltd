aset = {10,10,10,20,30,30,30}
bset = {30,30,30,30,30,40,40,40,50}
print(aset)
print(bset)
# unique elements of both aset and set
print(aset.union(bset))
# common element in both aset and bset
print(aset.intersection(bset))
# check whether aset is subset of bset
print(aset.issubset(bset))
# check whether aset is superset of bset
print(aset.issuperset(bset))
# add new value to aset
aset.add(30)
print(aset)
aset.add(80)
print(aset)
