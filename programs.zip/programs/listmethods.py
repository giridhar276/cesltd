alist = [12,45,32,4,78,61,36,100]
# add an element to the end of the list
alist.append(71)
print('After appending :',alist)
# add multiple values
alist.extend([18,28,31])
print('After extending :',alist)
#list.insert(index,value)
alist.insert(1,80)
print('After inserting :',alist)
#list.pop(index)
alist.pop()   # if index is not passed, last value will be popped out
print('After pop operation :',alist)
alist.pop(1)
print('After pop operation :',alist)
#list.remove(value)
alist.remove(32)
print('After removing :',alist)
alist.remove(300)
print('After removing :',alist)
alist.sort() # ascending by default
print('After sorting :', alist)
alist.sort(reverse = True)
print('After sorting(rev) :', alist)
alist.reverse()
print('After reversing :',alist)


