name = 'python programming'
print(name.islower())

if name.islower():
    print('string is lower')
    print('inside if')
    print('still inside if')



############ if -else # #####
if name.startswith("p"):
    print('its python programming')
else:
    print('Its hadoop ecosystem')
    
    
### if-elif-elif-elif..else
lang = input("Enter any language:")

if lang== "python":
    print('python programming')
elif lang == 'unix':
    print('unix shell scripting')
elif lang == 'java':
    print('java programming')
elif lang == 'oracle':
    print('oracle')
else:
    print('its some other language')

    
    
    
    
    
    
    
    