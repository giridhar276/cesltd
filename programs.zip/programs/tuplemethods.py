# list
alist = [10,20,30,40]
alist[0] = 100
print('After replacing :',alist)


# tuple
atup = (20,30,40,50)
atup[1] = 300
print('After replacing :',atup)
# typecasting - converting from one object to another object
alist = list(atup)  # step1: convert to list
alist.append(80)    # step2: make changes
atup = tuple(alist) # step3: again converting back to tuple
print(atup)