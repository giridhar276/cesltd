# string slicing
name = 'python programming'
print(name[0])
print(name[1])
# string[start:stop:incremental]
print(name[0:5])
print(name[8:15])
print(name[3:])
print(name[:5])
print(name[0:18:1])
print(name[0:18])
print(name[0:18:2])
print(name[1:18:2])
print(name[0:18:3])
print(name[:])
print(name[::])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])

name = 'python programming language'

print(name.capitalize())

print(name.title())

print(name.center(30))
print(name.center(30,"*"))

print(name.count('p',11,15))
print(name.count('z'))

print(name.endswith('g'))
print(name.endswith('m'))

print(name.startswith('m'))
print(name.startswith('p'))

print(name.split(" "))

print(name.replace('python','ruby'))

aname = ' python  '
print(len(aname))
print(len(aname.strip()))  # remove white spaces at both ends
print(len(aname.rstrip())) # remove white space only at right
print(len(aname.lstrip()))

print(aname.isupper())
print(aname.islower())
print(aname.isalpha())

## convert the strint to upper
print(aname.upper())
print(aname.lower())

bname = "I love {} and {}"
print(bname.format('unix','linux'))
print(bname.format('apple','orange'))
print(bname.format(1,2))























