

print(10,20,30)

value = 10
print("the value is",value)

name = 'python programming'
print("I love",name)

# this is the single line comment

"""
this is
multiline 
comment
"""